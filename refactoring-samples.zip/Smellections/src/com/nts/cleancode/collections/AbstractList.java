package com.nts.cleancode.collections;

public abstract class AbstractList extends AbstractCollection {
}
