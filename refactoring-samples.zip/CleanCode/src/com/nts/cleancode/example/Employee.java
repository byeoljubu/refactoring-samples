package com.nts.cleancode.example;

import java.util.EnumSet;

public abstract class Employee {
	protected EnumSet<Job> jobs;
}
